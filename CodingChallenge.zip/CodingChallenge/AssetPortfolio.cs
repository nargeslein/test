using System;
using System.Collections.Generic;

namespace CodingChallenge
{
    public class AssetPortfolio
    {
        public List<Stock> Portfolio { get; set; } = new List<Stock>();

        public void Add(Stock s)
        {
            Portfolio.Add(s);
        }

        public double Value()
        {
            double v = 0;
            foreach (var s in Portfolio)
            {
                v += s.Value();
            }
            return v;
        }

        public AssetPortfolio Consolidate()
        {
            //TODO:
            throw new NotImplementedException();
        }
    }
}