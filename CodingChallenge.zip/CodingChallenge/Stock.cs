namespace CodingChallenge
{
    public class Stock
    {
        public Stock(string symbol, double shares, double price)
        {
            Symbol = symbol;
            Shares = shares;
            Price = price;
        }

        public string Symbol { get; set; }
        public double Shares { get; set; }
        public double Price { get; set; }

        public double Value()
        {
            return Shares * Price;
        }
    }
}