using System.Collections.Generic;

namespace CodingChallenge
{
	/// <summary>
	/// implementation of stock with share and price, this is general stock
	/// </summary>
	public class Stock : Asset
	{
		/// <summary>
		/// Shares as property
		/// </summary>
		public double Shares { get; set; }
		/// <summary>
		/// Price as property
		/// </summary>
		public double Price { get; set; }

		public Stock(string symbol, string currency, double shares, double price) : base(symbol, currency)
		{
			Shares = shares;
			Price = price;
		}
		/// <summary>
		/// The value of a stock is shares * price
		/// </summary>
		/// <returns></returns>
		public override double Value()
		{
			return Shares * Price;
		}

		public override Asset Consolidate(List<Asset> assets)
		{
			if (assets.Count == 1)
				return assets[0] as Stock; 

			double newShares = 0;
			double newPrice = 0;
		
			var firstasset = assets[0] as Stock;
			foreach (var asset in assets)
			{
				if (firstasset.Equals(asset))
				{
					Stock stock = asset as Stock;
					newShares += stock.Shares;
					newPrice += (stock.Price * stock.Shares);
				}
				else
					throw new System.Exception(string.Format("Asset symbols are different, asset {0} cannot be consolidated with asset {1}", asset.Symbol, firstasset.Symbol));
			}

			newPrice = newShares != 0 ? newPrice / newShares : 0;
			return new Stock(firstasset.Symbol, firstasset.Currency, newShares, newPrice);
		}

	}
}