﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingChallenge
{	/// <summary>
	/// abstract class for Asset which can be extended for any kind of asset
	/// </summary>
	public abstract class Asset
	{
		/// <summary>
		/// Asset symbol as property
		/// </summary>
		public string Symbol { get; set; }

		/// <summary>
		/// asset currency as property
		/// </summary>
		public string Currency { get; set; }

		/// <summary>
		/// abstract method returning the value of the asset
		/// </summary>
		/// <returns></returns>
		abstract public double Value();

		/// <summary>
		/// abstract method to consolidate a list of assets 
		/// </summary>
		/// <param name="asset"></param>
		abstract public Asset Consolidate(List<Asset> asset); 

		public Asset(string symbol, string currency)
		{
			Symbol = symbol;
			Currency = currency;
		}

		/// <summary>
		/// method to value asset in another currency
		/// </summary>
		/// <param name="exchangeRates"></param>
		/// <param name="ToCurrency"></param>
		/// <returns></returns>
		public double Value(IExchangeRates exchangeRates, string ToCurrency)
		{
			return Value() * exchangeRates.GetRate(this.Currency, ToCurrency);
		}

		public override string ToString()
		{
			return string.Format("Asset '{0}' is {1} - value {2} {3}", Symbol, this.GetType().Name, Value(), Currency); 
		}

		/// <summary>
		/// overriding the Equals method so that assets with the same symbol are equal
		/// </summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			if (obj == null)
				return false;


			Asset asset = obj as Asset;

			return (!string.IsNullOrEmpty(asset.Symbol)) && (this.Symbol == asset.Symbol); 
		}

	}
}
