﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingChallenge
{/// <summary>
 /// implementation of domestic stock as subclass of Stock
 /// </summary>
	public class DomesticStock : Stock
	{
		public DomesticStock(string symbol, double shares, double price) : base(symbol, AssetPortfolio.EUR, shares, price)
		{

		}
	}
}