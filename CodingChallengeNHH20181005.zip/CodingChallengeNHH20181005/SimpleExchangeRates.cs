﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingChallenge
{
	/// <summary>
	/// simple implementation of exchange rates using a dictionary 
	/// </summary>
	public class SimpleExchangeRatesImplementation : IExchangeRates
	{
		Dictionary<CurrencyKey, double> rates = new Dictionary<CurrencyKey, double>();

		public double GetRate(string fromCurrency, string toCurrency)
		{
			if (fromCurrency == toCurrency || string.IsNullOrEmpty(fromCurrency)) 
				return 1; 
			CurrencyKey key = new CurrencyKey(fromCurrency, toCurrency); 
			return rates[key]; 

		}

		public void AddRate(string fromCurrency, string toCurrency, double rate)
		{
			rates.Add(new CurrencyKey(fromCurrency, toCurrency), rate);
			
		}		
	}

	struct CurrencyKey
	{
		public string fromCurrency;
		public string toCurrency;
		public CurrencyKey(string c1, string c2)
		{
			fromCurrency = c1;
			toCurrency = c2;
		}
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		public override bool Equals(object obj)
		{
			return base.Equals(obj);
		}
	}
}

