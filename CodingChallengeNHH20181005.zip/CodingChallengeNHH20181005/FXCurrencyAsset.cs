﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingChallenge
{   /// <summary>
	/// implementation of FX currency asset with amount in FX currency
	/// </summary>
	public class FXCurrencyAsset : Asset
	{
		/// <summary>
		/// Amount of FX currency 
		/// </summary>
		public double Amount { get; set; }

		/// <summary>
		/// constructor for creating FX currency asset
		/// </summary>
		/// <param name="symbol">asset symbol</param>
		/// <param name="currency">currency of the asset</param>
	    /// <param name="amount">amount of asset in FX currency</param>
		public FXCurrencyAsset(string symbol, string currency, double amount) : base(symbol, currency)
		{
			Amount = amount; 			
		}

		/// <summary>
		/// The value of a FX currency is the amount in FX currency
		/// </summary>
		/// <returns></returns>
		public override double Value()
		{
			return Amount;
		}

		/// <summary>
		/// consolidates a list of asset from the same asset class, similarity is based on the asset symbol
		/// </summary>
		/// <param name="assets">list of assets</param>
		/// <returns>consolidated asset</returns>
		public override Asset Consolidate(List<Asset> assets)
		{
			double amount = 0;
			var firstasset = assets[0] as FXCurrencyAsset; 
			foreach (var asset in assets)
			{
				if (firstasset.Equals(asset)) 
					amount += ((FXCurrencyAsset)asset).Amount;
				else
					throw new System.Exception(string.Format("Asset symbols are different, asset {0} cannot be consolidated with asset {1}", asset.Symbol, firstasset.Symbol));
			}
			return new FXCurrencyAsset(firstasset.Symbol, firstasset.Currency, amount); 
		}
	}
}
