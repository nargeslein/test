using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodingChallenge
{
	/// <summary>
	/// asset portfolio class
	/// </summary>
	public class AssetPortfolio
	{

		/// <summary>
		/// Domestic currency 
		/// </summary>
		public const string EUR = "EUR";

		public String Name { get; set; }


		public AssetPortfolio(IExchangeRates exchangeRates, string name)
		{		
			ExchangeRates = exchangeRates;
			Name = name;
		}

		public AssetPortfolio(IExchangeRates exchangeRates, string name, List<Asset> Portfolio)
		{			
			ExchangeRates = exchangeRates;
			Name = name;
			this.Portfolio = Portfolio;
		}

		/// <summary>
		/// list of assets in portfolio
		/// </summary>
		public List<Asset> Portfolio { get; set; } = new List<Asset>();


		/// <summary>
		/// Exchange rates used to value the portfolio
		/// </summary>
		public IExchangeRates ExchangeRates { get; set; }

		public void Add(Asset s)
		{
			Portfolio.Add(s);
		}


		public double Value(string toCurrency)
		{
			double v = 0;
			foreach (var s in Portfolio)
				v = v + s.Value(ExchangeRates, toCurrency);

			return v;
		}

		public double Value()
		{
			return Value(EUR); ;
		}


		public AssetPortfolio Consolidate()
		{
			AssetPortfolio ap = new AssetPortfolio(ExchangeRates, string.Format("consolidated  {0}", this.Name));
			var distinct = Portfolio.Select(p => p.Symbol).Distinct();

			foreach (var el in distinct)
			{
				var group = Portfolio.Where(e => e.Symbol == el).ToList();
				Asset asset = group[0] as Asset;
				Asset newAsset = asset.Consolidate(group);
				ap.Portfolio.Add(newAsset);
			}

			return ap;
		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendLine(string.Format("Portfolio '{0}' value {1} EUR with these {2} assets:", Name, Value(), Portfolio.Count));
			foreach (var asset in Portfolio)
				sb.AppendLine("\t" + asset.ToString());

			return sb.ToString();
		}
	}
}