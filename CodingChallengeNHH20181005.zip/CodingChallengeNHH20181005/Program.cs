﻿using System;
using System.Collections.Generic;

namespace CodingChallenge
{
	/// <summary>
	/// this programm runs a couple of tests in order to test the implementation
	/// </summary>
	internal class Program
	{
		public const string EUR = "EUR";
		public const string GBP = "GBP";
		public const string USD = "USD";

		private static void Main(string[] args)
		{
			//first set of tests with simple rates 1:1
			var rates = new SimpleExchangeRatesImplementation();
			rates.AddRate(EUR, GBP, 1);
			rates.AddRate(EUR, USD, 1);
			rates.AddRate(GBP, EUR, 1);
			rates.AddRate(USD, EUR, 1);
			rates.AddRate(GBP, USD, 1);

			List<Asset> t1 = new List<Asset>
			{
				new DomesticStock("ABC", 200, 4),
				new DomesticStock("ABC", 200, 4)
			};

			List<Asset> t2 = new List<Asset>
			{
				new Stock("ABCGBP", GBP, 200, 4),
				new DomesticStock("ABC", 200, 4)
			};

			List<Asset> t3 = new List<Asset>
			{
				new Stock("ABCGBP", GBP, 200, 4),
				new Stock("ABCUSD", USD, 200, 4),
				new DomesticStock("ABC", 200, 4)
			};

			List<Asset> t4 = new List<Asset>
			{
				new Stock("ABCGBP", GBP, 200, 4),
				new Stock("ABCUSD", USD, 200, 4),
				new DomesticStock("ABC", 200, 4),
				new FXCurrencyAsset("GBP", GBP, 100),
				new FXCurrencyAsset("USD", USD, 100)
			};

			var portfolio1 = new AssetPortfolio(rates, "Domestic stock portfolio", t1);
			var portfolio2 = new AssetPortfolio(rates, "Simple stock portfolio", t2);
			var portfolio3 = new AssetPortfolio(rates, "Stock Portfolio", t3);
			var portfolio4 = new AssetPortfolio(rates, "Mixed Portfolio", t4);

			//testing the values of the portfolios in different currencies
			TestValuation(portfolio1, 1600, EUR);
			TestValuation(portfolio2, 1600, EUR);
			TestValuation(portfolio3, 2400, EUR);
			TestValuation(portfolio4, 2600, EUR);

			TestValuation(portfolio1, 1600, EUR);
			TestValuation(portfolio2, 1600, GBP);
			TestValuation(portfolio3, 2400, USD);
			TestValuation(portfolio4, 2600, EUR);

			//second set of tests using 'some' exchange rates
			var rates2 = new SimpleExchangeRatesImplementation();
			rates2.AddRate(EUR, GBP, 2);
			rates2.AddRate(EUR, USD, 0.5);
			rates2.AddRate(GBP, EUR, 0.5);
			rates2.AddRate(USD, EUR, 2);
			rates2.AddRate(GBP, USD, 0.25);
			rates2.AddRate(USD, GBP, 4);

			var portfolio5 = new AssetPortfolio(rates2, "Domestic stock portfolio", t1);
			var portfolio6 = new AssetPortfolio(rates2, "Simple stock portfolio", t2);
			var portfolio7 = new AssetPortfolio(rates2, "Stock Portfolio", t3);
			var portfolio9 = new AssetPortfolio(rates2, "Mixed Portfolio", t4);

			//testing the values of the portfolios in different currencies
			TestValuation(portfolio5, 1600, EUR); 
			TestValuation(portfolio5, 1600 * rates2.GetRate(EUR, USD), USD); 
			TestValuation(portfolio6, 1200, EUR);

			TestValuation(portfolio7, 2800, EUR);
			TestValuation(portfolio7, 5600, GBP);
			TestValuation(portfolio7, 1400, USD);

			//testing the consolidation of the portfolio
			TestConsolidation(rates); 
					   			 		  
			Console.WriteLine("Done... (Press a key to close)");
			Console.ReadKey();
		}


		private static void TestValuation(AssetPortfolio assetPortfolio, double expected, string currency)
		{		

			Assert(AreEqual(assetPortfolio.Value(currency), expected), string.Format(
				" !!!Test {0} Failed, Expected Value: {1} \t ,\t Actual Value: \t {2} in {3}", assetPortfolio.Name, expected, assetPortfolio.Value(currency),currency));
			Console.Write(assetPortfolio); 
		}





		private static void TestConsolidation(IExchangeRates rates)
		{
			List<Asset> assets = new List<Asset> {
			new Stock("ABCGBP", "GBP", 200, 4),
			new Stock("ABCGBP", "GBP", 200, 4),

			new Stock("ABCUSD", "USD", 200, 4),

			new DomesticStock("ABC", 200, 4),
			new DomesticStock("ABC", 100, 8),
			new DomesticStock("ABC", 400, 8),

			new FXCurrencyAsset("GBP", "GBP", 100),
			new FXCurrencyAsset("GBP", "GBP", 200),
			new FXCurrencyAsset("GBP", "GBP", 300),

			new FXCurrencyAsset("USD", "USD", 100),
			new FXCurrencyAsset("USD", "USD", 200),
			new FXCurrencyAsset("USD", "USD", 300)
			}; 

			var portfolio = new AssetPortfolio(rates, "Original Portfolio", assets);


			TestValuation(portfolio, 8400, EUR); 

			//there are 12 assets
			Assert(AreEqual(portfolio.Portfolio.Count, 12),
				" !!!Test Failed, Expected numer of assets:" + "\t" + 12 + ",\t" + "Actual number: \t" + portfolio.Portfolio.Count + "\n");

			Console.WriteLine("---Consolidating Portfolio---");

			AssetPortfolio portfolioConsolidated = portfolio.Consolidate();

			TestValuation(portfolioConsolidated, 8400, EUR);

			//consolidated into 5 assets
			Assert(AreEqual(portfolioConsolidated.Portfolio.Count, 5),
				" !!!Test Failed, Expected numer of assets:" + "\t" + 5 + ",\t" + "Actual number: \t" + portfolioConsolidated.Portfolio.Count + "\n");
		}





		private static void Assert(bool condition, string failure)
		{
			if (!condition)
				Console.WriteLine(failure);
		}

		private static bool AreEqual(double d1, double d2)
		{
			return Math.Abs(d1 - d2) < .0001;
		}

		private static bool AreEqual(int i1, int i2)
		{
			return i1 == i2;
		}

		private static bool AreEqual(string s1, string s2)
		{
			return s1 == s2;
		}

	}
}