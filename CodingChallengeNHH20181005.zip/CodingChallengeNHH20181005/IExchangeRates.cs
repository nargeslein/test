namespace CodingChallenge
{
	/// <summary>
	/// interface for exchange rates
	/// </summary>
	public interface IExchangeRates
    {
        double GetRate(string fromCurrency, string toCurrency);
    }
}